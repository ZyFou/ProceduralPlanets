// Type declarations for procedural-planets.
// Parameter keys live in ./params.d.ts (generated from the engine defaults).

import type {
  Object3D, Vector3, WebGLRenderer, WebGLRenderTarget, PerspectiveCamera, Group,
  Raycaster, Intersection,
} from 'three';
import type { Pass } from 'three/examples/jsm/postprocessing/Pass.js';
import type { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import type { PlanetParams, ResolvedPlanetParams, ColorInput } from './params';
import type { HeightGraph, TerrainConfiguration, TerrainResult } from './graph';

export type { PlanetParams, ResolvedPlanetParams, ColorInput };
export * from './graph';

/** Public body types. */
export type PlanetType = 'terrestrial' | 'gas' | 'star';
/** Internal render modes (the `mode` parameter). */
export type PlanetMode = 'planet' | 'gas' | 'star';

export type TerrestrialPresetName =
  | 'terran' | 'desert' | 'ice' | 'moon' | 'lava' | 'ocean' | 'mars' | 'swamp' | 'alien' | 'ashen' | 'candy';
export type GasPresetName = 'gasGiant' | 'ringed' | 'iceGiant' | 'toxic' | 'nebular';
export type StarPresetName = 'sun' | 'redGiant' | 'blueGiant' | 'whiteDwarf' | 'ember' | 'eldritch';
export type PresetName = TerrestrialPresetName | GasPresetName | StarPresetName;

/** Kinds of regional weather system. */
export type WeatherSystemType = 'storm' | 'hurricane' | 'rain' | 'clear';

/**
 * A regional weather system: a spherical cap on the planet that thickens,
 * towers, rains, flashes or clears the clouds under it. Times are seconds on
 * the weather clock (planet.weather.time, advanced x weatherSpeed).
 */
export interface WeatherSystemDefinition {
  type: WeatherSystemType;
  /** Optional stable id (runtime systems get one from add()). */
  id?: string | number;
  name?: string;
  /** Centre latitude / longitude in degrees (y = north pole, longitude like sunAzimuth). */
  lat?: number;
  lon?: number;
  /** Centre as a planet-local direction (overrides lat / lon). */
  direction?: Vector3;
  /** Radius in degrees of arc (storm 6, hurricane 10, rain 12, clear 10). */
  radius?: number;
  /** 0..1 overall strength (default 1). */
  intensity?: number;
  /** 0..1 how much cloud the system builds (clear: how much it removes). */
  coverage?: number;
  /** 0..1 precipitation under the system. */
  rain?: number;
  /** 0..2 lightning activity (x the lightningAmount parameter). */
  lightning?: number;
  /** 0..1 how deep the convection is (tall towers / anvils). */
  tower?: number;
  /** Hurricanes: eye radius as a fraction of the radius (default 0.075). */
  eye?: number;
  /** Hurricanes: spin in rad / s, positive = counter-clockwise seen from above (default by hemisphere). */
  spin?: number;
  /** Track: heading in degrees (0 north, 90 east) and speed in degrees of arc per second. */
  heading?: number;
  speed?: number;
  /** Lifecycle: start time, duration (0 = forever), fade in / out, period (repeat, 0 = once). */
  start?: number;
  duration?: number;
  fadeIn?: number;
  fadeOut?: number;
  period?: number;
}

export interface WeatherAddOptions extends WeatherSystemDefinition {
  /** Seconds from now (when start is not given; start defaults to now). */
  delay?: number;
}

/** A live weather system (planet.weather.list()). */
export interface WeatherSystemState {
  id: string | number;
  source: 'runtime' | 'declared' | 'procedural';
  type: WeatherSystemType;
  lat: number;
  lon: number;
  /** intensity x fades, 0..1 */
  strength: number;
  /** current radius in degrees (systems grow while forming) */
  radius: number;
  definition: WeatherSystemDefinition;
}

/** Weather the systems put at a direction (planet.weather.sample()). */
export interface WeatherSample {
  rain: number;
  storm: number;
  hurricane: number;
  clear: number;
  lightning: number;
}

/** Fired on a Planet for every lightning strike (planet.addEventListener('lightning', ...)). */
export interface LightningEvent {
  type: 'lightning';
  /** World position: the ground strike point, or the flash inside the cloud. */
  position: Vector3;
  /** Planet-local direction of the strike. */
  direction: Vector3;
  intensity: number;
  /** Cloud-to-ground (true) or in-cloud flash. */
  ground: boolean;
  system: string | number | null;
}

/** planet.weather — regional, timed weather on a terrestrial planet. */
export class PlanetWeather {
  /** Weather clock, seconds (Planet.update advances it x weatherSpeed). Settable. */
  time: number;
  /** True when systems, rain and lightning render (terrestrial, clouds + weather on). */
  readonly enabled: boolean;
  /** Add a runtime system (fadeIn 4 s / fadeOut 6 s by default); returns its id. */
  add(definition: WeatherAddOptions): string | number;
  /** Change a runtime system; with { duration } numeric fields glide over that many seconds. */
  update(id: string | number, patch: Partial<WeatherSystemDefinition>, options?: { duration?: number }): boolean;
  /** Fade a runtime system out and drop it. */
  remove(id: string | number, options?: { fadeOut?: number }): boolean;
  /** Fade every runtime system out (default 4 s). */
  clear(options?: { fadeOut?: number }): void;
  /** A copy of a runtime system's definition. */
  get(id: string | number): WeatherSystemDefinition | null;
  /** Every system alive now (runtime, declared, procedural). */
  list(): WeatherSystemState[];
  /** Weather from the systems at a planet-local direction (CPU, analytic). */
  sample(direction: Vector3): WeatherSample;
  /** Fire a lightning strike now (in a system, or at a direction). */
  strike(options?: { direction?: Vector3; system?: string | number; intensity?: number; ground?: boolean }): boolean;
}

export const WEATHER_TYPES: readonly WeatherSystemType[];
export const MAX_WEATHER_SYSTEMS: number;
export function latLonToDirection(lat: number, lon: number, target?: Vector3): Vector3;
export function directionToLatLon(direction: Vector3): { lat: number; lon: number };
export function normalizeWeatherSystem(definition: WeatherSystemDefinition): WeatherSystemDefinition | null;

/** Where a planet's sunlight comes from. */
export type LightSource = Object3D | Vector3 | null;

/** Lossless sparse spherical runtime layers, independent from Studio editor state. */
export interface SerializedPlanetPaint {
  version: 1;
  mapping: 'cube-vertices';
  /** Quads per face (16..512); Studio defaults to 256. */
  resolution: number;
  encoding: 'sparse-zlib-f32le';
  /** Base64 zlib payload: sparse tiles of signed height and five material weights. */
  data: string;
}

export interface PlanetOptions extends PlanetParams {
  /** Body type (default: the preset's type, else 'terrestrial'). */
  type?: PlanetType;
  /** Named look (see listPresets()). */
  preset?: PresetName;
  /** A parameter object (e.g. from the studio). Flat keys on the options override it. */
  params?: PlanetParams;
  /** Terrestrial height generation source. Retained when displaying Gas or Star. */
  terrain?: TerrainConfiguration;
  paint?: SerializedPlanetPaint | null;
  /**
   * Light direction: an Object3D (a Planet star, a DirectionalLight, any object: the
   * light comes from its world position), a world-space Vector3 pointing toward the
   * sun, or null to use the sunAzimuth / sunElevation parameters (planet-local).
   */
  lightSource?: LightSource;
  /** Custom starSurface() GLSL body (stars). */
  starShader?: string;
  name?: string;
}

export interface SerializedPlanet {
  app: 'procedural-planets';
  version: 2;
  mode: PlanetMode;
  params: ResolvedPlanetParams;
  terrain: TerrainConfiguration;
  paint?: SerializedPlanetPaint;
  /** Custom star surface shader, if present. */
  starShader?: string;
}

export interface LegacySerializedPlanet {
  app: 'procedural-planets';
  version: 1;
  mode: PlanetMode;
  params: ResolvedPlanetParams;
  starShader?: string;
}

/** Editable Studio document. Editor data has no effect on the runtime. */
export interface PlanetProjectDocument {
  schemaVersion: 2;
  id: string;
  metadata: { name: string; [key: string]: unknown };
  params: PlanetParams;
  terrain: TerrainConfiguration;
  paint?: SerializedPlanetPaint | null;
  editor?: { draftGraph?: HeightGraph | null; nodePositions?: Record<string, { x: number; y: number }>;
    nodeLabels?: Record<string, string>; groups?: unknown[]; viewport?: { x: number; y: number; zoom: number } | null;
    [key: string]: unknown };
  [key: string]: unknown;
}

export interface ShaderResult { ok: boolean; error?: string }

/**
 * A procedural terrestrial planet, gas giant or star. It is a THREE.Object3D:
 * add it to your scene, position / rotate / (uniformly) scale / parent it
 * like any object. It draws nothing through renderer.render(); a
 * PlanetRenderer draws it.
 */
export class Planet extends Object3D {
  constructor(options?: PlanetOptions);
  readonly isPlanet: true;
  /** 'terrestrial' | 'gas' | 'star' (Object3D.type is 'Planet'). */
  readonly planetType: PlanetType;
  /** Current parameters (treat as read-only; use set()). */
  readonly params: ResolvedPlanetParams;
  /** A detached copy of the applied terrain configuration. */
  readonly terrain: TerrainConfiguration;
  /** Detached runtime paint snapshot. Paint remains active after leaving the editor. */
  readonly paint: SerializedPlanetPaint;
  /** Restore paint only; null clears paint. Invalid data throws without changing layers. */
  setPaint(paint: SerializedPlanetPaint | null): this;
  /** Light direction source, see PlanetOptions.lightSource. */
  lightSource: LightSource;
  /** Shader clock in seconds (waves, star surface, gas flow). */
  time: number;
  /** Integrated cloud clock. */
  cloudTime: number;
  /** Regional, timed weather: storms, hurricanes, rain, clear skies, lightning. */
  readonly weather: PlanetWeather;
  /** Radius (local units) of a sphere containing everything the planet draws. */
  readonly boundingRadius: number;
  /** Radius (local units) of the solid / liquid surface used for picking. */
  readonly surfaceRadius: number;
  /** starSurface() GLSL body in use. */
  readonly starShaderBody: string;

  get<K extends keyof ResolvedPlanetParams>(key: K): ResolvedPlanetParams[K];
  /** Set parameters live (validated; colours accept any ColorInput). */
  set(patch: PlanetParams): this;
  set<K extends keyof PlanetParams>(key: K, value: PlanetParams[K]): this;
  /** Low-level, unvalidated single-key setter. */
  setParam<K extends keyof ResolvedPlanetParams>(key: K, value: ResolvedPlanetParams[K]): void;
  /** Apply a named preset (switches the body type unless setType: false). */
  applyPreset(name: PresetName, options?: { setType?: boolean }): this;
  /** Pick a new random seed; returns it. */
  randomizeSeed(): number;
  /** Replace the star surface shader (compile-checked when a renderer is known). */
  setStarShader(glslBody: string, renderer?: WebGLRenderer | null): ShaderResult;
  /** Validate and atomically apply a graph. Failed candidates retain the previous terrain. */
  setTerrainGraph(graph: HeightGraph, options?: { renderer?: WebGLRenderer | null }): Promise<TerrainResult>;
  setTerrain(terrain: TerrainConfiguration, options?: { renderer?: WebGLRenderer | null }): Promise<TerrainResult>;
  /** Ignore any pending shader compilation candidate. */
  cancelTerrainCompilation(): void;

  /** Terrain radius (local units) along a LOCAL direction (CPU height mirror). */
  getSurfaceRadius(direction: Vector3): number;
  /** Procedural/node elevation before paint, in planet-local units. */
  getBaseElevation(direction: Vector3): number;
  /** World-space point on the surface (terrain or sea) along a LOCAL direction. */
  getSurfacePoint(direction: Vector3, target?: Vector3): Vector3;
  raycast(raycaster: Raycaster, intersects: Intersection[]): void;

  /** Advance the planet clocks (PlanetRenderer does this unless autoUpdate is off). */
  update(delta: number): void;
  /**
   * Glide parameters to new values over `duration` seconds of planet time
   * (numbers and colours; rebuild / re-bake keys and counts switch at once).
   */
  transition(patch: PlanetParams, options?: { duration?: number }): this;
  /** Parameter keys with a transition still running. */
  readonly transitioning: string[];
  addEventListener(type: 'lightning', listener: (event: LightningEvent) => void): void;
  removeEventListener(type: 'lightning', listener: (event: LightningEvent) => void): void;

  /** Plain JSON, same shape as the studio's planet_preset.json. */
  serialize(): SerializedPlanet;
  /** From a studio export / project / parameter object (older studio params are migrated). */
  static fromJSON(json: string | SerializedPlanet | LegacySerializedPlanet | PlanetProjectDocument | { params: PlanetParams; terrain?: TerrainConfiguration; paint?: SerializedPlanetPaint | null } | PlanetParams, options?: PlanetOptions): Planet;
  /** Free the planet's GPU resources. */
  dispose(): void;
}

export interface PlanetRendererOptions {
  /** 'transparent' (default): composite over your frame. 'stars': the farthest planet owns the frame, opaque, with a starfield. */
  background?: 'transparent' | 'stars';
  /**
   * 'auto' (default): 'display' for the canvas and sRGB render targets, 'linear' for linear targets.
   * 'display': ACES tone mapped (sRGB encoded, or linear into an sRGB target that encodes on write).
   * 'linear': premultiplied linear HDR for HDR / composer pipelines.
   */
  output?: 'auto' | 'display' | 'linear';
  /** Depth-test planets against your depth buffer (default true). */
  depthTest?: boolean;
  /** Write planet surfaces into your depth buffer (default true). */
  depthWrite?: boolean;
  /** Shade only each planet's screen rectangle (default true). */
  scissor?: boolean;
  /** Advance planet clocks from an internal clock when no delta is passed (default true). */
  autoUpdate?: boolean;
  /** Clamp for the internal clock step, seconds (default 0.05). */
  maxDelta?: number;
  /** Draw distant planets as impostors: a cached picture on a billboard (default true). */
  impostors?: boolean;
  /** Screen radius (px) under which a planet becomes an impostor (default 90). */
  impostorPixels?: number;
  /** Impostor pictures re-rendered per frame at most (default 2). */
  impostorUpdates?: number;
  /** View / sun direction change (degrees) that makes an impostor stale (default 0.6). */
  impostorAngle?: number;
  /** Planet-clock seconds between impostor refreshes, for clouds and waves (default 0.5). */
  impostorRefresh?: number;
  /** Largest impostor atlas edge in px; starts at 512 and doubles when full (default 2048). */
  impostorAtlasSize?: number;
}

export interface PrepareProgress {
  stage: 'shaders' | 'noise' | 'weather' | 'prime';
  /** Overall progress 0..1. */
  progress: number;
  /** Where the current stage ends (0..1), e.g. to animate a loading bar toward it. */
  stageEnd: number;
  done: number;
  total: number;
}

export interface PrepareOptions {
  /** Also compile the other body types and optional layers, so later switches never wait (default false). */
  modes?: boolean;
  /** Run the one-time GPU bakes too (default true). */
  bake?: boolean;
  /** The render target the planets will be drawn into (default: the renderer's current one). */
  target?: WebGLRenderTarget | null;
  onProgress?: (progress: PrepareProgress) => void;
}

export interface PlanetRenderOptions {
  /** Output target (default: the renderer's current render target). Needs a depth buffer for occlusion. */
  target?: WebGLRenderTarget | null;
  /** Seconds to advance the planets' clocks (default: internal clock if autoUpdate). */
  delta?: number;
}

/** Draws Planet objects with your WebGLRenderer (WebGL2). One per renderer. */
export class PlanetRenderer {
  constructor(renderer: WebGLRenderer, options?: PlanetRendererOptions);
  readonly renderer: WebGLRenderer;
  readonly options: Required<PlanetRendererOptions>;
  /**
   * Stats of the last render(): planets drawn / culled, pending (skipped while their
   * shaders compile in the background), impostors (drawn as billboards), captures
   * (impostor pictures rendered this frame).
   */
  readonly info: { planets: number; culled: number; pending: number; impostors: number; captures: number };
  /** Planets the last render() skipped because their shaders are still compiling. */
  readonly pending: number;
  setOptions(options: PlanetRendererOptions): this;
  /** Release cached impostors for a removed body; the caller still owns and disposes the Planet. */
  release(planet: Planet): void;
  /**
   * Draw every visible Planet in `planets` (an object tree to traverse, a Planet or an
   * array). Call after rendering your opaque scene into the same target.
   */
  render(planets: Object3D | Planet | Planet[], camera: PerspectiveCamera, options?: PlanetRenderOptions): void;
  /**
   * Get planets ready without stalling the page: shaders compile in parallel, the one-time
   * GPU bakes run a slice per frame. When it resolves the next render() draws them at full
   * quality: the place to hide a loading screen.
   */
  prepare(planets: Object3D | Planet | Planet[], camera?: PerspectiveCamera | null, options?: PrepareOptions): Promise<void>;
  /** prepare() without the bakes: compile the shaders ahead, without blocking. */
  compile(planets: Planet | Planet[], camera?: PerspectiveCamera): Promise<void>;
  dispose(): void;
}

export interface PlanetStats { fps: number; triangles: number; drawCalls: number; chunks: number; pending: number }

export interface PlanetViewerOptions {
  /** Canvas to render into... */
  canvas?: HTMLCanvasElement;
  /** ...or an element to create a full-size canvas in. */
  container?: HTMLElement;
  /** A Planet (not disposed by the viewer) or Planet options (default: terran). */
  planet?: Planet | PlanetOptions;
  /** OrbitControls (default true). */
  controls?: boolean;
  /** Start the render loop (default true). */
  autoStart?: boolean;
  /** Max device pixel ratio (default 2). */
  pixelRatio?: number;
  onStats?: (stats: PlanetStats) => void;
}

/** A self-contained single-planet view: renderer, camera, controls, loop, starfield. */
export class PlanetViewer {
  constructor(options: PlanetViewerOptions);
  readonly renderer: WebGLRenderer;
  readonly planetRenderer: PlanetRenderer;
  readonly camera: PerspectiveCamera;
  readonly controls: OrbitControls | null;
  readonly canvas: HTMLCanvasElement;
  readonly planet: Planet;
  readonly running: boolean;
  setPlanet(planet: Planet | PlanetOptions): Planet;
  /** Reset the camera to the default 3/4 view. */
  frame(): this;
  start(): this;
  stop(): this;
  /** One frame without advancing time. */
  renderOnce(): void;
  /**
   * Compile the planet's shaders (in parallel), run its bakes and draw its first frame.
   * Resolves once that final-quality frame is on the canvas.
   */
  prepare(options?: PrepareOptions): Promise<this>;
  /** PNG data URL of a native-resolution w x h frame, independent of viewport renderResolution. */
  screenshot(width?: number, height?: number): string;
  /** A small image (data URL) copied from the next frame that draws the planet: no extra render. */
  captureThumbnail(width?: number, height?: number, type?: string, quality?: number): Promise<string | null>;
  dispose(): void;
}

export interface BakeOptions extends PlanetOptions {
  /** Bake this planet instead of creating one from the other options. */
  planet?: Planet;
  /** Quads per cube-face side (terrestrial) / sphere segments (default 128). */
  meshResolution?: number;
  /** Texture size per face / equirect width (default 1024). */
  textureSize?: number;
  /** Translucent ocean shell (default true). */
  water?: boolean;
  /** Fresnel atmosphere / corona rim shell (default true). */
  atmosphere?: boolean;
  /** Gas giant rings (default true). */
  rings?: boolean;
  /** Fold a fixed sun into the textures (default false: your lights shade the meshes). */
  bakeLighting?: boolean;
  /** Star surface material: 'basic' unlit (default) or 'standard' emissive. */
  starMaterial?: 'basic' | 'standard';
  onProgress?: (message: string) => void;
}

export interface BakedPlanet extends Group {
  userData: { params: ResolvedPlanetParams; terrain: TerrainConfiguration; [key: string]: unknown };
  /** Dispose every geometry, material and texture of the group. */
  dispose(): void;
}

/** Bake a planet into static standard-material meshes (lit by your scene). */
export function bakePlanet(renderer: WebGLRenderer, options?: BakeOptions): Promise<BakedPlanet>;

export interface PlanetPassOptions extends PlanetRendererOptions {
  /** Reuse an existing PlanetRenderer. */
  planetRenderer?: PlanetRenderer;
}

/** EffectComposer pass: put it right after RenderPass (never last; add an OutputPass). */
export class PlanetPass extends Pass {
  constructor(scene: Object3D | Planet[], camera: PerspectiveCamera, options?: PlanetPassOptions);
  scene: Object3D | Planet[];
  camera: PerspectiveCamera;
  planetRenderer: PlanetRenderer | null;
}

export interface ParamDoc {
  domain: PlanetMode;
  group: string;
  label: string;
  type: 'number' | 'boolean' | 'color' | 'string';
  default: number | boolean | string | [number, number, number];
  description: string;
  min?: number;
  max?: number;
  step?: number;
  structural?: boolean;
}

/** Metadata for every parameter (for building UIs, validation, docs). */
export const PARAM_DOCS: Record<keyof ResolvedPlanetParams, ParamDoc>;

export interface PresetDef { label: string; patch: PlanetParams }
export const PLANET_PRESETS: Record<TerrestrialPresetName, PresetDef>;
export const GAS_PRESETS: Record<GasPresetName, PresetDef>;
export const STAR_PRESETS: Record<StarPresetName, PresetDef>;
export const DEFAULT_PARAMS: ResolvedPlanetParams;
export const GAS_DEFAULTS: Partial<ResolvedPlanetParams>;
export const STAR_DEFAULTS: Partial<ResolvedPlanetParams>;
export const DEFAULT_STAR_BODY: string;
export const PLANET_TYPES: Readonly<Record<'terrestrial' | 'planet' | 'gas' | 'star', PlanetMode>>;
export const VERSION: string;

export function listPresets(): Record<PlanetType, string[]>;
export function findPreset(name: string): { mode: PlanetMode; preset: PresetDef } | null;
export function validateParams(patch: Record<string, unknown>): { params: PlanetParams; unknown: string[]; invalid: string[] };
export function normalizeParam(key: string, value: unknown): { ok: boolean; value?: unknown; reason?: 'unknown' | 'invalid' };
export function resolvePlanetParams(options?: PlanetOptions): ResolvedPlanetParams;
export function migrateParams(params: PlanetParams, presetKey?: TerrestrialPresetName, modePreset?: Partial<Record<PlanetMode, string>>): PlanetParams;
